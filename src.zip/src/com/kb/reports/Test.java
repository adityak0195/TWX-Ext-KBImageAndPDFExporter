package com.kb.reports;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String URL = "smartproductionlibdev.corp.knorr-bremse.com/Thingworx/Runtime/index.html#master=KBSmartProductionMaster1Mashup&mashup=KBProductionAdvisorCvsMashup"
				+ "&x-thingworx-session=true";
		String URLlower = URL.toLowerCase();

		String test = URL;
		
		URL = URL.replace("#", "&");
		URL = URL.replace("?", "&");
		URLlower = URL.toLowerCase();

		if (URLlower.contains("master=")) {
			int poss = URLlower.indexOf("master=");
			int pose = URLlower.indexOf("&",poss);

			URL = URL.substring(0, poss) + URL.substring(pose+1); 
			URLlower = URL.toLowerCase();
		}
		if (URLlower.contains("mashup=")) {
			int poss = URLlower.indexOf("mashup=");
			int pose = URLlower.indexOf("&",poss);
			String mashup = URL.substring(poss+7, pose);

			URL = URL.replace(URL.substring(poss, pose),""); 
			URL = URL.replace("Runtime/index.html", "Mashups/"+mashup+"?appKey=cbe766c9-7ca0-46fb-bac4-3add72f1f6a2"); 
			URLlower = URL.toLowerCase();
		}
		
		URL = URL.replace("&&", "&");
		URLlower = URL.toLowerCase();

		System.out.println(URL);
		System.out.println(test);

	}

}
