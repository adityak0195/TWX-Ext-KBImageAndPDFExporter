package com.kb.reports;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.imageio.ImageIO;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.thingworx.entities.utils.ThingUtilities;
import com.thingworx.things.repository.FileRepositoryThing;

public class GenerateSFMPDF {
	
	 public String generateFile(String url1, String url2, String fileName, String fileRepository) throws Exception {
		 
	
	 BufferedImage weekReportImage=generateSFMWeeklyReport.generateWeeklyReport(url2);
	 BufferedImage dailyReportImage=generateSFMDailyReport.generateDailyReport(url1);
	 
	FileRepositoryThing filerepo = (FileRepositoryThing) ThingUtilities.findThing(fileRepository);
				
	filerepo.processServiceRequest("GetDirectoryStructure", null);
	String output = filerepo.getRootPath() + File.separator + fileName;
	FileOutputStream fos = new FileOutputStream(output);
	Document document = new Document();
	// Instantiate the PDF writer
	PdfWriter writer = PdfWriter.getInstance(document, fos);
	
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	ImageIO.write(dailyReportImage, "png", baos);
	baos.flush();
	ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
	
	Image iTextImage = Image.getInstance(baos.toByteArray());
	
    ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
    ImageIO.write(weekReportImage, "png", baos1);
    baos1.flush();
    Image iTextImage1 = Image.getInstance(baos1.toByteArray());
	
	// open the pdf for writing
	writer.open();
	document.open();
	
	document.setPageSize(iTextImage);
	document.newPage();
    iTextImage.setAbsolutePosition(0, 0);

	// add the captured image to PDF
    document.add(iTextImage);    

    document.setPageSize(iTextImage1);
    document.newPage();    
    iTextImage1.setAbsolutePosition(0, 0);	
	document.add(iTextImage1);
	
	// close the files and write to local system
	document.close();
	writer.close();

	
	 return "PDF Created Successfully";
			
	 }
}
