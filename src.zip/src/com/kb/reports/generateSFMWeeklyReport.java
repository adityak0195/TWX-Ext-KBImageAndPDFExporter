package com.kb.reports;

import java.awt.Graphics2D;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class generateSFMWeeklyReport {
	static int pageHeight = 0;
	static int count = 0;
	static WebDriver driver;
	static List<BufferedImage> images = new LinkedList<BufferedImage>();

	
	// WebDriver driver;
		public static BufferedImage generateWeeklyReport(String url) throws Exception {
			System.setProperty("webdriver.chrome.driver","C:\\KBData\\chromedriver_win32\\chromedriver.exe");
		//	WebDriverManager.chromedriver().setup();
			
			ChromeOptions options = new ChromeOptions();			
			options.addArguments("no-sandbox");
			options.addArguments("--headless");
			options.setAcceptInsecureCerts(true);
			options.addArguments("window-size=2048x1536");
			options.addArguments("disable-blink-features=AutomationControlled");
			options.addArguments("--disable-gpu");
			options.addArguments("--incognito");
			
			WebDriver driver = new ChromeDriver(options);
			
			Thread.sleep(2000);		
			
			driver.get(url);		
			Thread.sleep(40000);
			JavascriptExecutor exc=(JavascriptExecutor)driver;
			
			WebElement section = driver.findElement(By.xpath("//*[@id=\"root_collection-3\"]"));

			BufferedImage finalImage = pageScrollable(section, exc);
			driver.quit();
			return finalImage;
		}

		public static BufferedImage pageScrollable(WebElement section, JavascriptExecutor jse) throws Exception {	

			jse.executeScript("document.querySelector('#root_collection-3').scrollTo(0,0)");
			// Find page height
			int pageHeight = ((Number) jse.executeScript(" return document.querySelector('#root_collection-3').scrollHeight")).intValue();
			// Find current browser dimensions and isolate its height
			int browserSize = ((Number) jse.executeScript("return document.querySelector('#root_collection-3').clientHeight")).intValue();

			int currentHeight = 0;

			// Scrolling logic
			while (pageHeight >= currentHeight) {
				screenShot(section);
				currentHeight += browserSize;
				jse.executeScript("document.querySelector('#root_collection-3').scrollBy(0," + browserSize + ")");

				Thread.sleep(2000);

			}

			BufferedImage result = null;
			Graphics2D g2d = null;
			int heightCurr = 0;
			int imageHeight = 0;

			for (int i = 0; i < images.size(); i++) {
				BufferedImage img = images.get(i);
				int imgHeight = img.getHeight();

				if (result == null) {

					imageHeight = pageHeight + images.size() * (img.getHeight() - browserSize);
				
					result = new BufferedImage(img.getWidth(), imageHeight, img.getType());
					g2d = result.createGraphics();
				}
				if (i == images.size() - 1) {

					g2d.drawImage(img, 0, (imageHeight - img.getHeight()), null);				
				} else {
					g2d.drawImage(img, 0, heightCurr, null);
					heightCurr += img.getHeight();
				}
			}
			g2d.dispose();
		
			return result;
		}

		public static void screenShot(WebElement section) throws IOException, InterruptedException {
			byte[] scr = section.getScreenshotAs(OutputType.BYTES);
			BufferedImage img = ImageIO.read(new ByteArrayInputStream(scr));
			images.add(img);
		}

}