package com.kb.reports;

//import java.awt.Dimension;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.Dimension;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.thingworx.entities.utils.ThingUtilities;
import com.thingworx.things.repository.FileRepositoryThing;

import io.github.bonigarcia.wdm.WebDriverManager;


/**
 * @author kapoory(Yugum Kapoor)
 *
 */
public class GeneratePDF {
	
	public String pdfGenerate(String url, String fileName , String fileRepository) throws Exception {
		
		WebDriverManager.chromedriver().setup();		
		ChromeOptions options = new ChromeOptions();		
		options.addArguments("no-sandbox");
		options.addArguments("--headless");
//		options.setHeadless(true);
		options.setAcceptInsecureCerts(true);
		options.addArguments("window-size=2048x1536");
		options.addArguments("disable-blink-features=AutomationControlled");
		options.addArguments("--disable-gpu");
		
		WebDriver driver = new ChromeDriver(options);	

		String URL = url;
		if (!url.startsWith("https://")) {
			URL = "https://" + url;
		}
			
		
		driver.get(URL);		
				
		Thread.sleep(40000);		

		byte[] input = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		FileRepositoryThing filerepo = (FileRepositoryThing) ThingUtilities.findThing(fileRepository);
		
		filerepo.processServiceRequest("GetDirectoryStructure", null);
		Document document = new Document();
		String output = filerepo.getRootPath() + File.separator + fileName;
		FileOutputStream fos = new FileOutputStream(output);

		// Instantiate the PDF writer
		PdfWriter writer = PdfWriter.getInstance(document, fos);

		// open the pdf for writing
		writer.open();
		document.open();

		// process content into image
		Image im = Image.getInstance(input);

		// set the size of the image
		im.scalePercent(50,50);

		// add the captured image to PDF
		document.add(im);
		document.add(new Paragraph(" "));

		// close the files and write to local system
		document.close();
		writer.close();

		driver.quit();
		
		
		return "PDF File Generated Successfully.";
	}

}
