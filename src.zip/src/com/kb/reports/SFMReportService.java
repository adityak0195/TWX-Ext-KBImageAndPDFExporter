package com.kb.reports;

public class SFMReportService {

	
	public String generate(String appkey, String url1, String url2, String fileName, String fileRepository) throws Exception	{
		
		try {

			String URL1 = getURL(url1,appkey);
			String URL2= getURL(url2, appkey);
			
			return new GenerateSFMPDF().generateFile(URL1, URL2, fileName, fileRepository );			

			}
			catch(Exception e) {
				
				throw e;
			}
		
		}
	
	public String getURL(String url, String appkey) {
		String URL = url + "&x-thingworx-session=true";
		String URLlower = URL.toLowerCase();
		
		URL = URL.replace("#", "&");
		URL = URL.replace("?", "&");
		URLlower = URL.toLowerCase();

		if (URLlower.contains("master=")) {
			int poss = URLlower.indexOf("master=");
			int pose = URLlower.indexOf("&",poss);

			URL = URL.substring(0, poss) + URL.substring(pose+1); 
			URLlower = URL.toLowerCase();
		}
		if (URLlower.contains("mashup=")) {
			int poss = URLlower.indexOf("mashup=");
			int pose = URLlower.indexOf("&",poss);
			String mashup = URL.substring(poss+7, pose);

			URL = URL.replace(URL.substring(poss, pose),""); 
			URL = URL.replace("Runtime/index.html", "Mashups/"+mashup+"?appKey="+appkey); 
			URLlower = URL.toLowerCase();
		}
		
		URL = URL.replace("&&", "&");
		return URL;
	
	}
}
