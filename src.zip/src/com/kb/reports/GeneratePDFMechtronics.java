package com.kb.reports;

import java.io.File;
import java.io.FileOutputStream;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.thingworx.entities.utils.ThingUtilities;
import com.thingworx.things.repository.FileRepositoryThing;

public class GeneratePDFMechtronics {
	
public String pdfGenerate(String url1, String url2,String fileName , String fileRepository) throws Exception {
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","C:\\KBApps\\Chrome_Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.manage().window().getSize();		
		driver.manage().window().setSize(new Dimension(1920,1080));			

		String URL1 = url1;
		if (!url1.startsWith("https://")) {
			URL1 = "https://" + url1;
		}
		
		String URL2 = url2;
		if (!url2.startsWith("https://")) {
			URL2 = "https://" + url1;
		}
			
		
		driver.get(URL1);
		
		Thread.sleep(10000);
		
		((JavascriptExecutor) driver).executeScript("document.body.style.zoom='80%';");	
		
		Thread.sleep(30000);		

		byte[] input1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		
		driver.get(URL2);
		
		Thread.sleep(10000);
		
		((JavascriptExecutor) driver).executeScript("document.body.style.zoom='80%';");	
		
		Thread.sleep(30000);		

		byte[] input2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		
		FileRepositoryThing filerepo = (FileRepositoryThing) ThingUtilities.findThing(fileRepository);
		
		filerepo.processServiceRequest("GetDirectoryStructure", null);
		Document document = new Document();
		String output = filerepo.getRootPath() + File.separator + fileName;
		FileOutputStream fos = new FileOutputStream(output);

		// Instantiate the PDF writer
		PdfWriter writer = PdfWriter.getInstance(document, fos);

		// open the pdf for writing
		writer.open();
		document.open();

		// process content into image
		Image im1 = Image.getInstance(input1);

		// set the size of the image
		im1.scalePercent(50,50);
		
		// process content into image
		Image im2 = Image.getInstance(input1);

		// set the size of the image
		im2.scalePercent(50,50);
		// add the captured image to PDF
		document.add(im1);
		document.add(im2);
		document.add(new Paragraph(" "));

		// close the files and write to local system
		document.close();
		writer.close();

		driver.quit();
		
		
		return URL1 +"and :  "+ URL2;
	}


}
