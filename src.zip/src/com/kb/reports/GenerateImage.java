package com.kb.reports;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.assertthat.selenium_shutterbug.core.Capture;
import com.assertthat.selenium_shutterbug.core.CaptureElement;
import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.thingworx.entities.utils.ThingUtilities;
import com.thingworx.things.repository.FileRepositoryThing;

import io.github.bonigarcia.wdm.WebDriverManager;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;



/**
 * @author kapoory(Yugum Kapoor)
 *
 */
public class GenerateImage {
	
	public String imageGenerate(String url, String fileName, String fileRepository) throws Exception {
		
		//System.setProperty("webdriver.chrome.driver","C:\\KBApps\\Chrome_Driver\\chromedriver.exe");
		WebDriverManager.chromedriver().setup();
		
		ChromeOptions options = new ChromeOptions();
		
		options.addArguments("no-sandbox");
		options.addArguments("--headless");
	//	options.setHeadless(true);
		options.setAcceptInsecureCerts(true);
		options.addArguments("window-size=2048x1536");
		options.addArguments("disable-blink-features=AutomationControlled");
		options.addArguments("--disable-gpu");
		
		WebDriver driver = new ChromeDriver(options);

		//driver.manage().window().maximize();
		Thread.sleep(10000);

		String URL = url;
		if (!url.startsWith("https://")) {
			URL = "https://" + url;
		}
		
		driver.get(URL);
		Thread.sleep(10000);
				
		Thread.sleep(30000);
		FileRepositoryThing filerepo = (FileRepositoryThing) ThingUtilities.findThing(fileRepository);
		
		filerepo.processServiceRequest("GetDirectoryStructure", null);
		String output = filerepo.getRootPath() + File.separator  +  fileName;
		
		Screenshot screenshot = new AShot().takeScreenshot(driver);		
		
		Thread.sleep(30000);		

		ImageIO.write(screenshot.getImage(), "PNG", new File(output));			
	
		driver.quit();

		return "PNG File Created Successfully";
	}

}
