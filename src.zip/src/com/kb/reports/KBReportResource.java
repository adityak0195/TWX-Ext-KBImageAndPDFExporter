package com.kb.reports;

import org.slf4j.Logger;

import com.thingworx.logging.LogUtilities;
import com.thingworx.metadata.annotations.ThingworxServiceDefinition;
import com.thingworx.metadata.annotations.ThingworxServiceParameter;
import com.thingworx.metadata.annotations.ThingworxServiceResult;
import com.thingworx.resources.Resource;

/**
 * @author Yugum Kapoor
 *
 */

public class KBReportResource extends Resource {

	private static final long serialVersionUID = 1L;
	private static Logger _logger = LogUtilities.getInstance().getApplicationLogger(KBReportResource.class);
	
	@ThingworxServiceDefinition(name = "GenerateFile", description = "Generating PDF or PNG based on File type", category = "", isAllowOverride = false, aspects = {"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "STRING", aspects = {})
	
	public String GenerateFile(	
		@ThingworxServiceParameter(name ="Appkey", description = "Appkey who has access to the mashup", baseType= "STRING" , aspects = {"isRequired:true"})
		String appkey,
		@ThingworxServiceParameter(name ="URL", description = "URL of Mashup", baseType= "STRING" , aspects = {"isRequired:true"})
		String url,
		@ThingworxServiceParameter(name ="Type", description = "Type of the file", baseType= "STRING" , aspects = {"isRequired:true"})
		String type,
		
		@ThingworxServiceParameter(name ="FileName", description = "Name of output file", baseType= "STRING" , aspects = {"isRequired:true"})
		String fileName,
		
		@ThingworxServiceParameter(name = "FileRepository", description = "Choose a file repository where the output file will be stored.", baseType = "THINGNAME", aspects = {"defaultValue:SystemRepository", "thingTemplate:FileRepository"})  
		String fileRepository
		
		
		) throws Exception {
		return new ReportService().generate(appkey,url,type,fileName,fileRepository);
	}
	
	@ThingworxServiceDefinition(name = "GenerateSFMReport", description = "Generating PDF for Mechatronics Reports", category = "", isAllowOverride = false, aspects = {"isAsync:false" })
	@ThingworxServiceResult(name = "Result", description = "", baseType = "STRING", aspects = {})
	public String GenerateSFMReport(	
			@ThingworxServiceParameter(name ="Appkey", description = "Appkey who has access to the mashup", baseType= "STRING" , aspects = {"isRequired:true"})
			String appkey,
			@ThingworxServiceParameter(name ="URL1", description = "URL of Mashup", baseType= "STRING" , aspects = {"isRequired:true"})
			String url1,
			@ThingworxServiceParameter(name ="URL2", description = "URL of Second mashup", baseType= "STRING" , aspects = {"isRequired:true"})
			String url2,
			
			@ThingworxServiceParameter(name ="FileName", description = "Name of output file", baseType= "STRING" , aspects = {"isRequired:true"})
			String fileName,
			
			@ThingworxServiceParameter(name = "FileRepository", description = "Choose a file repository where the output file will be stored.", baseType = "THINGNAME", aspects = {"defaultValue:SystemRepository", "thingTemplate:FileRepository"})  
			String fileRepository			
			
			) throws Exception {
			return new SFMReportService().generate(appkey,url1,url2,fileName,fileRepository);
		}
	


 
	 
	 @ThingworxServiceDefinition(name = "GeneratePDFPrintFile", description = "Generating PDF using the print of page", category = "", isAllowOverride = false, aspects = {"isAsync:false" })

     @ThingworxServiceResult(name = "Result", description = "", baseType = "STRING", aspects = {})

     public String GeneratePDFPrintFile(    

     @ThingworxServiceParameter(name ="Appkey", description = "Appkey who has access to the mashup", baseType= "STRING" , aspects = {"isRequired:true"})

     String appkey,

     @ThingworxServiceParameter(name ="URL", description = "URL of Mashup", baseType= "STRING" , aspects = {"isRequired:true"})

     String url,

     @ThingworxServiceParameter(name ="FileName", description = "Name of output file", baseType= "STRING" , aspects = {"isRequired:true"})

     String fileName,
     
     @ThingworxServiceParameter(name = "FileRepository", description = "Choose a file repository where the output file will be stored.", baseType = "THINGNAME", aspects = {"defaultValue:SystemRepository", "thingTemplate:FileRepository"})  

     String fileRepository
        
     ) throws Exception {

        return new ReportService().generateFile(appkey,url,fileName,fileRepository);

    }
     
     @ThingworxServiceDefinition(name = "GenerateSFMPDFPrintFile", description = "Generating SFM PDF using the print of page", category = "", isAllowOverride = false, aspects = {"isAsync:false" })

     @ThingworxServiceResult(name = "Result", description = "", baseType = "STRING", aspects = {})

     public String GenerateSFMPDFPrintFile(    

     @ThingworxServiceParameter(name ="Appkey", description = "Appkey who has access to the mashup", baseType= "STRING" , aspects = {"isRequired:true"})

     String appkey,

     @ThingworxServiceParameter(name ="URL", description = "URL of Mashup", baseType= "STRING" , aspects = {"isRequired:true"})

     String url,

     @ThingworxServiceParameter(name ="FileName", description = "Name of output file", baseType= "STRING" , aspects = {"isRequired:true"})

     String fileName,
     
     @ThingworxServiceParameter(name = "FileRepository", description = "Choose a file repository where the output file will be stored.", baseType = "THINGNAME", aspects = {"defaultValue:SystemRepository", "thingTemplate:FileRepository"})  

     String fileRepository
        
     ) throws Exception {

        return new ReportService().generateSFM(appkey,url,fileName,fileRepository);

    }

}
