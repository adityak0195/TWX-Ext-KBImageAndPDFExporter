package com.kb.reports;

import java.io.IOException;
import java.net.MalformedURLException;

import com.itextpdf.text.DocumentException;



/**
 * @author kapoory(Yugum Kapoor)
 *
 */
public class ReportService {
	
	
	public String generate(String appkey, String url, String type, String fileName, String fileRepository) throws Exception	{
	
		try {

			String URL = url + "&x-thingworx-session=true";
			String URLlower = URL.toLowerCase();
			
			URL = URL.replace("#", "&");
			URL = URL.replace("?", "&");
			URLlower = URL.toLowerCase();

			if (URLlower.contains("master=")) {
				int poss = URLlower.indexOf("master=");
				int pose = URLlower.indexOf("&",poss);

				URL = URL.substring(0, poss) + URL.substring(pose+1); 
				URLlower = URL.toLowerCase();
			}
			if (URLlower.contains("mashup=")) {
				int poss = URLlower.indexOf("mashup=");
				int pose = URLlower.indexOf("&",poss);
				String mashup = URL.substring(poss+7, pose);

				URL = URL.replace(URL.substring(poss, pose),""); 
				URL = URL.replace("Runtime/index.html", "Mashups/"+mashup+"?appKey="+appkey); 
				URLlower = URL.toLowerCase();
			}
			
			URL = URL.replace("&&", "&");
			
			
			if(type.equalsIgnoreCase("pdf")) {
			
				return new GeneratePDF().pdfGenerate(URL, fileName, fileRepository);	
			}
			else
			{
				return new GenerateImage().imageGenerate(URL, fileName, fileRepository);
			}
				
			}
			catch(Exception e) {
				
				throw e;
			}
		
		}

	
	
	public String generateFile(String appkey, String url, String fileName, String fileRepository) throws Exception	{
		
		try {

			String URL = url + "&x-thingworx-session=true";
			String URLlower = URL.toLowerCase();
			
			URL = URL.replace("#", "&");
			URL = URL.replace("?", "&");
			URLlower = URL.toLowerCase();

			if (URLlower.contains("master=")) {
				int poss = URLlower.indexOf("master=");
				int pose = URLlower.indexOf("&",poss);

				URL = URL.substring(0, poss) + URL.substring(pose+1); 
				URLlower = URL.toLowerCase();
			}
			if (URLlower.contains("mashup=")) {
				int poss = URLlower.indexOf("mashup=");
				int pose = URLlower.indexOf("&",poss);
				String mashup = URL.substring(poss+7, pose);

				URL = URL.replace(URL.substring(poss, pose),""); 
				URL = URL.replace("Runtime/index.html", "Mashups/"+mashup+"?appKey="+appkey); 
				URLlower = URL.toLowerCase();
			}
			
			URL = URL.replace("&&", "&");
			
			return new GeneratePrintPDF().printPdfGenerate(URL, fileName, fileRepository);	
			
			}
		
			catch(Exception e) {
				
				throw e;
			}
		
		}
	

	
	public String generateSFM(String appkey, String url, String fileName, String fileRepository) throws Exception	{
		
		try {

			String URL = url + "&x-thingworx-session=true";
			String URLlower = URL.toLowerCase();
			
			URL = URL.replace("#", "&");
			URL = URL.replace("?", "&");
			URLlower = URL.toLowerCase();

			if (URLlower.contains("master=")) {
				int poss = URLlower.indexOf("master=");
				int pose = URLlower.indexOf("&",poss);

				URL = URL.substring(0, poss) + URL.substring(pose+1); 
				URLlower = URL.toLowerCase();
			}
			if (URLlower.contains("mashup=")) {
				int poss = URLlower.indexOf("mashup=");
				int pose = URLlower.indexOf("&",poss);
				String mashup = URL.substring(poss+7, pose);

				URL = URL.replace(URL.substring(poss, pose),""); 
				URL = URL.replace("Runtime/index.html", "Mashups/"+mashup+"?appKey="+appkey); 
				URLlower = URL.toLowerCase();
			}
			
			URL = URL.replace("&&", "&");
			
			return new GeneratePrintPDF().printSFMPdfGenerate(URL, fileName, fileRepository);	
			
			}
		
			catch(Exception e) {
				
				throw e;
			}
		
		}
	
}
