package com.kb.reports;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.Pdf;
import org.openqa.selenium.TakesScreenshot;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.print.PageMargin;
import org.openqa.selenium.print.PageSize;
import org.openqa.selenium.print.PrintOptions;
import org.openqa.selenium.chrome.ChromeDriver;

import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;

import com.thingworx.things.repository.FileRepositoryThing;
import com.thingworx.entities.utils.ThingUtilities;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class GeneratePrintPDF {

   
	public String printSFMPdfGenerate(String url, String fileName, String fileRepository) throws Exception {

		System.setProperty("webdriver.chrome.driver","C:\\KBData\\chromedriver_win32\\chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		
		options.addArguments("--headless");
		options.setAcceptInsecureCerts(true);
		options.addArguments("disable-blink-features=AutomationControlled");
		options.addArguments("--disable-gpu");
    	options.addArguments("--incognito");
 
    	// Create a new instance of ChromeDriver
        ChromeDriver driver = new ChromeDriver(options);

        String URL = url;
        if (!url.startsWith("https://")) {
            URL = "https://" + url;
        }

        // Navigate to the webpage you want to capture
        driver.get(URL);
        
        try {
            Thread.sleep(60000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        try {
            Thread.sleep(60000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        PrintOptions printOptions = new PrintOptions();
     
        PageSize pageSize = new PageSize(40, 13);
        printOptions.setBackground(true);
        printOptions.setOrientation(PrintOptions.Orientation.PORTRAIT);
        printOptions.setPageSize(pageSize);
        printOptions.setScale(.3);
        printOptions.setShrinkToFit(true);
        printOptions.setPageMargin(new PageMargin(0, 0, 0, 0));

        FileRepositoryThing filerepo = (FileRepositoryThing) ThingUtilities.findThing(fileRepository);
        filerepo.processServiceRequest("GetDirectoryStructure", null);
        String pdfOutput = filerepo.getRootPath() + File.separator + fileName;
        
        Pdf pdf = driver.print(printOptions);
        Files.write(Paths.get(pdfOutput), OutputType.BYTES.convertFromBase64Png(pdf.getContent()));
  
        // Close the driver
        driver.close();
        
        // Quit the driver
        driver.quit();

        return "SFM PDF file generated successfully.";
    }
	
	
	public String printPdfGenerate(String url, String fileName, String fileRepository) throws Exception {

		System.setProperty("webdriver.chrome.driver","C:\\KBData\\chromedriver_win32\\chromedriver.exe");

		ChromeOptions options = new ChromeOptions();
		
		options.addArguments("--headless");
		options.setAcceptInsecureCerts(true);
		options.addArguments("disable-blink-features=AutomationControlled");
		options.addArguments("--disable-gpu");
    	options.addArguments("--incognito");
    	options.addArguments("window-size=2000x2899");//1750x2100

    	// Create a new instance of ChromeDriver
        ChromeDriver driver = new ChromeDriver(options);
       
        String URL = url;
        if (!url.startsWith("https://")) {
            URL = "https://" + url;
        }

        // Navigate to the webpage you want to capture
        driver.get(URL);
    
        try {
            Thread.sleep(60000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        try {
            Thread.sleep(90000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Capture the screenshot as byte array
        byte[] screenshotBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
       
        FileRepositoryThing filerepo = (FileRepositoryThing) ThingUtilities.findThing(fileRepository);
        filerepo.processServiceRequest("GetDirectoryStructure", null);
        String pdfOutput = filerepo.getRootPath() + File.separator + fileName;
      
        // Create a new PDF document
        PdfDocument pdfDoc = new PdfDocument(new PdfWriter(pdfOutput));
        Document document = new Document(pdfDoc);

        // Add the captured image to the PDF
        Image im = new Image(ImageDataFactory.create(screenshotBytes));
        document.add(im);
        document.add(new Paragraph(" "));

        // Close the PDF document
        document.close();
        pdfDoc.close();

        // Close the driver
        driver.close();
        
        // Quit the driver
        driver.quit();

        return "PDF file generated successfully.";
    }

	
}
